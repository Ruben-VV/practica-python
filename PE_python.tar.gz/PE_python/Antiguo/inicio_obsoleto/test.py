##reset -f
##%pylab
import numpy
import matplotlib
import scipy

from matplotlib import pylab, mlab, pyplot
np = numpy
plt = pyplot

from IPython.display import display
from IPython.core.pylabtools import figsize, getfigs
from scipy import special, optimize

from pylab import *
from numpy import *
from scipy import *
